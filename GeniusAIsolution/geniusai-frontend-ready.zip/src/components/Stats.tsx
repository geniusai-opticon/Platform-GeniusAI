export default function Stats() {
  const stats = [
    {
      number: "12,000+",
      label: "Analysierte Verträge"
    },
    {
      number: "€2.1M", 
      label: "Eingesparte Kosten"
    },
    {
      number: "98%",
      label: "Zufriedene Kunden"
    },
    {
      number: "24h",
      label: "Durchschnittliche Bearbeitungszeit"
    }
  ];

  return (
    <section className="py-16 bg-[var(--genius-primary)] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 text-center">
          {stats.map((stat, index) => (
            <div key={index} className="space-y-2">
              <div className="text-4xl font-bold text-[var(--genius-secondary)]">
                {stat.number}
              </div>
              <div className="text-blue-100">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
