import { Button } from "@/components/ui/button";
import { Rocket, Play } from "lucide-react";

export default function Hero() {
  const handleStartFreeTrial = () => {
    window.location.href = "/api/login";
  };

  const handleWatchDemo = () => {
    const pricingSection = document.getElementById('pricing');
    if (pricingSection) {
      pricingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="pt-24 pb-16 bg-gradient-to-br from-[var(--genius-primary)] via-blue-600 to-[var(--genius-secondary)] text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-fade-in-up">
            <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
              KI-basierte Vertragsoptimierung der nächsten Generation
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed">
              Automatisieren Sie Ihre Vertragsanalyse mit modernster KI-Technologie. 
              Sparen Sie Zeit und Geld durch intelligente Optimierungsvorschläge.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={handleStartFreeTrial}
                className="bg-white text-[var(--genius-primary)] hover:bg-gray-100 px-8 py-4 text-lg font-semibold hover:shadow-xl transition-all duration-200 hover:scale-105"
              >
                <Rocket className="mr-2 h-5 w-5" />
                Kostenlos starten
              </Button>
              <Button
                onClick={handleWatchDemo}
                variant="outline"
                className="border-2 border-white text-white hover:bg-white hover:text-[var(--genius-primary)] px-8 py-4 text-lg font-semibold transition-all duration-200"
              >
                <Play className="mr-2 h-5 w-5" />
                Demo ansehen
              </Button>
            </div>
          </div>
          
          <div className="relative animate-fade-in-right">
            {/* Dashboard Preview Mock */}
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 shadow-2xl transform rotate-3 hover:rotate-1 transition-transform duration-500 animate-float">
              <div className="bg-white rounded-xl overflow-hidden shadow-lg">
                {/* Dashboard Header */}
                <div className="bg-[var(--genius-primary)] p-4 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 rounded-full bg-red-400"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                    <div className="w-3 h-3 rounded-full bg-green-400"></div>
                  </div>
                  <span className="text-white text-sm font-medium">Vertrags-Dashboard</span>
                </div>
                
                {/* Dashboard Content */}
                <div className="p-6 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-[var(--genius-primary)]">12</div>
                      <div className="text-sm text-gray-600">Aktive Verträge</div>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-[var(--genius-secondary)]">€2,340</div>
                      <div className="text-sm text-gray-600">Einsparpotential</div>
                    </div>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Analysierte Verträge</span>
                      <span>75%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-gradient-to-r from-[var(--genius-primary)] to-[var(--genius-secondary)] h-2 rounded-full w-3/4"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
