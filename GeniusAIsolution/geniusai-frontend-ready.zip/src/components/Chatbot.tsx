import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircle, X, Send, Bot, User } from "lucide-react";
import type { ChatMessage } from "@shared/schema";

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: messages = [], isLoading } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat/messages"],
    enabled: isAuthenticated && isOpen,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageText: string) => {
      const response = await apiRequest("POST", "/api/chat/message", {
        message: messageText,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages"] });
      setMessage("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    if (!isAuthenticated) {
      toast({
        title: "Anmeldung erforderlich",
        description: "Bitte melden Sie sich an, um den Chat zu nutzen.",
        variant: "destructive",
      });
      window.location.href = "/api/login";
      return;
    }

    sendMessageMutation.mutate(message);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Group messages by timestamp to show conversation flow
  const groupedMessages = messages.reduce((acc, msg) => {
    const lastGroup = acc[acc.length - 1];
    if (lastGroup && lastGroup[0]?.isBot === msg.isBot) {
      lastGroup.push(msg);
    } else {
      acc.push([msg]);
    }
    return acc;
  }, [] as ChatMessage[][]);

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <div className="relative">
        {/* Chat Window */}
        {isOpen && (
          <Card className="mb-4 w-96 h-96 shadow-2xl border border-gray-200 overflow-hidden">
            {/* Chat Header */}
            <div className="bg-[var(--genius-primary)] text-white p-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                  <Bot className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="font-semibold">GENIUS Assistant</h4>
                  <p className="text-xs text-blue-100">
                    {isAuthenticated ? "Online" : "Anmeldung erforderlich"}
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
                className="text-white hover:text-gray-200 hover:bg-white/10"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            {/* Chat Messages */}
            <div className="flex-1 p-4 space-y-4 overflow-y-auto h-64 bg-gray-50">
              {!isAuthenticated ? (
                <div className="text-center py-8">
                  <Bot className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-4">
                    Melden Sie sich an, um mit unserem KI-Assistenten zu chatten.
                  </p>
                  <Button
                    onClick={() => window.location.href = "/api/login"}
                    className="btn-genius-primary"
                  >
                    Anmelden
                  </Button>
                </div>
              ) : isLoading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[var(--genius-primary)] mx-auto"></div>
                  <p className="text-gray-600 mt-2">Chat wird geladen...</p>
                </div>
              ) : groupedMessages.length === 0 ? (
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-[var(--genius-primary)] rounded-full flex items-center justify-center text-white text-sm">
                    <Bot className="h-4 w-4" />
                  </div>
                  <Card className="bg-white max-w-xs">
                    <CardContent className="p-3">
                      <p className="text-sm">
                        Hallo! Ich bin Ihr KI-Assistent. Wie kann ich Ihnen bei Ihren Verträgen helfen?
                      </p>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                groupedMessages.map((group, groupIndex) => (
                  <div key={groupIndex} className={`flex items-start space-x-3 ${group[0]?.isBot ? '' : 'justify-end'}`}>
                    {group[0]?.isBot && (
                      <div className="w-8 h-8 bg-[var(--genius-primary)] rounded-full flex items-center justify-center text-white text-sm">
                        <Bot className="h-4 w-4" />
                      </div>
                    )}
                    <div className="space-y-2 max-w-xs">
                      {group.map((msg) => (
                        <Card 
                          key={msg.id} 
                          className={`${msg.isBot ? 'bg-white' : 'bg-[var(--genius-primary)] text-white'}`}
                        >
                          <CardContent className="p-3">
                            <p className="text-sm">{msg.message}</p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                    {!group[0]?.isBot && (
                      <div className="w-8 h-8 bg-gray-400 rounded-full flex items-center justify-center text-white text-sm">
                        <User className="h-4 w-4" />
                      </div>
                    )}
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>
            
            {/* Chat Input */}
            {isAuthenticated && (
              <div className="p-4 border-t border-gray-200 bg-white">
                <form onSubmit={handleSubmit} className="flex space-x-2">
                  <Input
                    type="text"
                    placeholder="Nachricht eingeben..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="flex-1 text-sm"
                    disabled={sendMessageMutation.isPending}
                  />
                  <Button
                    type="submit"
                    size="sm"
                    className="btn-genius-primary"
                    disabled={sendMessageMutation.isPending || !message.trim()}
                  >
                    {sendMessageMutation.isPending ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </form>
              </div>
            )}
          </Card>
        )}
        
        {/* Chat Toggle Button */}
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="bg-[var(--genius-primary)] hover:bg-[var(--genius-primary-dark)] text-white w-14 h-14 rounded-full shadow-lg transition-all duration-200 hover:scale-110 flex items-center justify-center"
        >
          {isOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <MessageCircle className="h-6 w-6" />
          )}
        </Button>
      </div>
    </div>
  );
}
