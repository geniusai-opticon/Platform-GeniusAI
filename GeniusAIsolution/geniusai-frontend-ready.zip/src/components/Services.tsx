import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Zap, Smartphone, Shield, Check } from "lucide-react";

export default function Services() {
  const services = [
    {
      icon: Zap,
      title: "Strom & Gas",
      description: "Automatische Analyse Ihrer Energieverträge mit Vergleich aktueller Marktpreise",
      features: [
        "Automatischer Tarifvergleich",
        "Kündigungsmanagement", 
        "Wechselservice"
      ],
      color: "text-[var(--genius-primary)]",
      borderColor: "border-t-[var(--genius-primary)]",
      buttonColor: "btn-genius-primary"
    },
    {
      icon: Smartphone,
      title: "Internet & TV",
      description: "Optimierung von Telekommunikationsverträgen mit intelligenten Empfehlungen",
      features: [
        "Tarifoptimierung",
        "Geschwindigkeitsanalyse",
        "Vertragskonsolidierung"
      ],
      color: "text-green-500",
      borderColor: "border-t-green-500",
      buttonColor: "bg-green-500 hover:bg-green-600 text-white"
    },
    {
      icon: Shield,
      title: "Versicherungen",
      description: "Vollständige Analyse Ihrer Versicherungsverträge für optimalen Schutz",
      features: [
        "Deckungsanalyse",
        "Beitragsoptimierung",
        "Lückenidentifikation"
      ],
      color: "text-[var(--genius-secondary)]",
      borderColor: "border-t-[var(--genius-secondary)]",
      buttonColor: "btn-genius-secondary"
    }
  ];

  const handleServiceSelect = (service: string) => {
    // Scroll to pricing section
    const pricingSection = document.getElementById('pricing');
    if (pricingSection) {
      pricingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Unsere Dienstleistungen</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Optimieren Sie Ihre Verträge mit modernster KI-Technologie und sparen Sie automatisch Kosten
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <Card 
                key={index} 
                className={`card-genius ${service.borderColor} border-t-4`}
              >
                <CardContent className="p-8">
                  <div className={`${service.color} text-4xl mb-6`}>
                    <IconComponent className="h-10 w-10" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h3>
                  <p className="text-gray-600 mb-6">
                    {service.description}
                  </p>
                  <ul className="space-y-3 mb-6">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                        <Check className="h-4 w-4 text-green-500 mr-3 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button
                    onClick={() => handleServiceSelect(service.title.toLowerCase())}
                    className={`w-full ${service.buttonColor} transition-colors`}
                  >
                    Service aktivieren
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
