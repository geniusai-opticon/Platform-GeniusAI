import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";

export default function AIAnalysisDemo() {
  const [analysisStep, setAnalysisStep] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const steps = [
    {
      number: 1,
      title: "OCR-Texterkennung",
      description: "Automatische Extraktion aller relevanten Vertragsdaten",
      color: "bg-[var(--genius-primary)]"
    },
    {
      number: 2, 
      title: "KI-Analyse mit GPT-4",
      description: "Intelligente Bewertung von Konditionen und Kündigungsfristen",
      color: "bg-[var(--genius-primary)]"
    },
    {
      number: 3,
      title: "Marktvergleich", 
      description: "Echtzeitvergleich mit aktuellen deutschen Marktpreisen",
      color: "bg-[var(--genius-primary)]"
    },
    {
      number: 4,
      title: "Optimierungsvorschläge",
      description: "Konkrete Handlungsempfehlungen mit Einsparpotential",
      color: "bg-[var(--genius-secondary)]"
    }
  ];

  const startDemo = () => {
    setIsAnimating(true);
    setAnalysisStep(0);
    
    const interval = setInterval(() => {
      setAnalysisStep(prev => {
        if (prev >= steps.length - 1) {
          clearInterval(interval);
          setTimeout(() => setIsAnimating(false), 2000);
          return prev;
        }
        return prev + 1;
      });
    }, 1500);
  };

  useEffect(() => {
    // Auto-start demo on mount
    const timer = setTimeout(startDemo, 1000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Vollautomatische KI-Optimierung</h2>
          <p className="text-xl text-gray-600">Sehen Sie, wie unsere KI Ihre Verträge in Echtzeit analysiert</p>
        </div>
        
        <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-3xl p-8 lg:p-12">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-6">
                {steps.map((step, index) => (
                  <div 
                    key={index}
                    className={`flex items-start space-x-4 transition-all duration-500 ${
                      isAnimating && analysisStep >= index 
                        ? 'opacity-100 scale-100' 
                        : isAnimating 
                          ? 'opacity-50 scale-95' 
                          : 'opacity-100 scale-100'
                    }`}
                  >
                    <div className={`w-8 h-8 ${step.color} rounded-full flex items-center justify-center text-white font-bold text-sm ${
                      isAnimating && analysisStep === index ? 'animate-pulse' : ''
                    }`}>
                      {step.number}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">{step.title}</h3>
                      <p className="text-gray-600">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              {!isAnimating && (
                <Button 
                  onClick={startDemo}
                  className="btn-genius-primary"
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  Demo starten
                </Button>
              )}
            </div>
            
            <div className="relative">
              {/* AI Analysis Mockup */}
              <Card className="shadow-2xl overflow-hidden">
                <div className="bg-gradient-to-r from-[var(--genius-primary)] to-[var(--genius-secondary)] p-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-white font-semibold">
                      {isAnimating ? `${steps[analysisStep]?.title} läuft...` : 'KI-Analyse bereit'}
                    </h4>
                    {isAnimating && (
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                        <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                      </div>
                    )}
                  </div>
                </div>
                
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-center justify-between py-2 border-b border-gray-100">
                    <span className="text-sm text-gray-600">Aktueller Tarif</span>
                    <span className="text-sm font-semibold text-red-600">€45.20/Monat</span>
                  </div>
                  
                  <div className="flex items-center justify-between py-2 border-b border-gray-100">
                    <span className="text-sm text-gray-600">Optimaler Tarif</span>
                    <span className="text-sm font-semibold text-green-600">€32.80/Monat</span>
                  </div>
                  
                  <Card className="bg-green-50 border-green-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-green-800">Jährliche Ersparnis</span>
                        <span className="text-lg font-bold text-green-800">€148.80</span>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Button className="w-full btn-genius-primary">
                    <Sparkles className="mr-2 h-4 w-4" />
                    Optimierung starten
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
