import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Navbar from "@/components/Navbar";
import FileUpload from "@/components/FileUpload";
import ContractCard from "@/components/ContractCard";
import Footer from "@/components/Footer";
import Chatbot from "@/components/Chatbot";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, TrendingUp, FileText, AlertTriangle, Euro } from "lucide-react";
import type { Contract } from "@shared/schema";

interface DashboardStats {
  totalContracts: number;
  activeContracts: number;
  monthlyCosts: number;
  potentialSavings: number;
  upcomingCancellations: number;
}

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const queryClient = useQueryClient();
  const [showUpload, setShowUpload] = useState(false);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: contracts, isLoading: contractsLoading } = useQuery<Contract[]>({
    queryKey: ["/api/contracts"],
    enabled: isAuthenticated,
  });

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
    enabled: isAuthenticated,
  });

  const deleteContractMutation = useMutation({
    mutationFn: async (contractId: string) => {
      await apiRequest("DELETE", `/api/contracts/${contractId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Contract deleted successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete contract",
        variant: "destructive",
      });
    },
  });

  const reanalyzeContractMutation = useMutation({
    mutationFn: async (contractId: string) => {
      await apiRequest("POST", `/api/contracts/${contractId}/reanalyze`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Contract re-analyzed successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to re-analyze contract",
        variant: "destructive",
      });
    },
  });

  if (isLoading || contractsLoading || statsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[var(--genius-primary)] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Willkommen zurück, {user?.firstName || 'User'}!
            </h1>
            <p className="text-gray-600">Hier ist Ihre aktuelle Vertragsübersicht</p>
          </div>

          {/* Stats Cards */}
          {stats && (
            <div className="grid md:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-600 text-sm">Aktive Verträge</p>
                      <p className="text-2xl font-bold">{stats.activeContracts}</p>
                    </div>
                    <FileText className="h-8 w-8 text-[var(--genius-primary)]" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-600 text-sm">Monatliche Kosten</p>
                      <p className="text-2xl font-bold">€{stats.monthlyCosts.toFixed(2)}</p>
                    </div>
                    <Euro className="h-8 w-8 text-red-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-600 text-sm">Einsparpotential</p>
                      <p className="text-2xl font-bold text-green-600">€{stats.potentialSavings.toFixed(2)}</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-600 text-sm">Kündigungen fällig</p>
                      <p className="text-2xl font-bold text-orange-600">{stats.upcomingCancellations}</p>
                    </div>
                    <AlertTriangle className="h-8 w-8 text-orange-500" />
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Upload Section */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold text-gray-900">Ihre Verträge</h2>
              <Button
                onClick={() => setShowUpload(!showUpload)}
                className="btn-genius-primary"
              >
                <Plus className="h-4 w-4 mr-2" />
                Vertrag hinzufügen
              </Button>
            </div>

            {showUpload && (
              <div className="mb-6">
                <FileUpload onSuccess={() => {
                  setShowUpload(false);
                  queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
                  queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
                }} />
              </div>
            )}
          </div>

          {/* Contracts Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {contracts?.map((contract) => (
              <ContractCard
                key={contract.id}
                contract={contract}
                onDelete={() => deleteContractMutation.mutate(contract.id)}
                onReanalyze={() => reanalyzeContractMutation.mutate(contract.id)}
                isDeleting={deleteContractMutation.isPending}
                isReanalyzing={reanalyzeContractMutation.isPending}
              />
            ))}
          </div>

          {contracts?.length === 0 && (
            <div className="text-center py-12">
              <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Keine Verträge vorhanden</h3>
              <p className="text-gray-600 mb-4">Laden Sie Ihren ersten Vertrag hoch, um zu beginnen.</p>
              <Button
                onClick={() => setShowUpload(true)}
                className="btn-genius-primary"
              >
                <Plus className="h-4 w-4 mr-2" />
                Ersten Vertrag hinzufügen
              </Button>
            </div>
          )}
        </div>
      </div>
      <Footer />
      <Chatbot />
    </div>
  );
}
