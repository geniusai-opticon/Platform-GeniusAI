import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, AlertCircle, FileUp, Eye, Brain } from "lucide-react";

interface UploadProgressProps {
  fileName: string;
  progress: number;
  stage: 'uploading' | 'ocr' | 'ai_analysis' | 'complete' | 'error';
  error?: string;
}

export default function UploadProgress({ fileName, progress, stage, error }: UploadProgressProps) {
  const getStageInfo = () => {
    switch (stage) {
      case 'uploading':
        return {
          icon: <FileUp className="h-4 w-4" />,
          text: "Datei wird hochgeladen...",
          color: "text-blue-700",
          bgColor: "bg-blue-50",
          borderColor: "border-blue-200"
        };
      case 'ocr':
        return {
          icon: <Eye className="h-4 w-4" />,
          text: "OCR-Texterkennung läuft...",
          color: "text-purple-700",
          bgColor: "bg-purple-50",
          borderColor: "border-purple-200"
        };
      case 'ai_analysis':
        return {
          icon: <Brain className="h-4 w-4" />,
          text: "KI-Analyse wird durchgeführt...",
          color: "text-orange-700",
          bgColor: "bg-orange-50",
          borderColor: "border-orange-200"
        };
      case 'complete':
        return {
          icon: <CheckCircle className="h-4 w-4" />,
          text: "Vertrag erfolgreich analysiert!",
          color: "text-green-700",
          bgColor: "bg-green-50",
          borderColor: "border-green-200"
        };
      case 'error':
        return {
          icon: <AlertCircle className="h-4 w-4" />,
          text: error || "Ein Fehler ist aufgetreten",
          color: "text-red-700",
          bgColor: "bg-red-50",
          borderColor: "border-red-200"
        };
      default:
        return {
          icon: <FileUp className="h-4 w-4" />,
          text: "Verarbeitung...",
          color: "text-gray-700",
          bgColor: "bg-gray-50",
          borderColor: "border-gray-200"
        };
    }
  };

  const stageInfo = getStageInfo();

  return (
    <div className="space-y-4">
      {/* File Progress Card */}
      <Card className="bg-gray-50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700 truncate" title={fileName}>
              {fileName}
            </span>
            <span className="text-sm text-gray-500">{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </CardContent>
      </Card>
      
      {/* Processing Status Card */}
      <Card className={`${stageInfo.bgColor} ${stageInfo.borderColor} border`}>
        <CardContent className="p-4">
          <div className="flex items-center">
            {stage !== 'complete' && stage !== 'error' && (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current mr-3" />
            )}
            {(stage === 'complete' || stage === 'error') && (
              <span className="mr-3">{stageInfo.icon}</span>
            )}
            <span className={`text-sm ${stageInfo.color}`}>
              {stageInfo.text}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Stage Indicators */}
      <div className="flex justify-between items-center text-xs text-gray-500">
        <div className={`flex items-center space-x-1 ${progress >= 25 ? 'text-blue-600' : ''}`}>
          <div className={`w-2 h-2 rounded-full ${progress >= 25 ? 'bg-blue-600' : 'bg-gray-300'}`} />
          <span>Upload</span>
        </div>
        <div className={`flex items-center space-x-1 ${progress >= 50 ? 'text-purple-600' : ''}`}>
          <div className={`w-2 h-2 rounded-full ${progress >= 50 ? 'bg-purple-600' : 'bg-gray-300'}`} />
          <span>OCR</span>
        </div>
        <div className={`flex items-center space-x-1 ${progress >= 75 ? 'text-orange-600' : ''}`}>
          <div className={`w-2 h-2 rounded-full ${progress >= 75 ? 'bg-orange-600' : 'bg-gray-300'}`} />
          <span>KI-Analyse</span>
        </div>
        <div className={`flex items-center space-x-1 ${progress >= 100 ? 'text-green-600' : ''}`}>
          <div className={`w-2 h-2 rounded-full ${progress >= 100 ? 'bg-green-600' : 'bg-gray-300'}`} />
          <span>Fertig</span>
        </div>
      </div>
    </div>
  );
}
