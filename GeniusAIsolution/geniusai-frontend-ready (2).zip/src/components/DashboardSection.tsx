import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, FileText, Euro, TrendingUp, AlertTriangle, Search, Sparkles } from "lucide-react";
import type { Contract } from "@shared/schema";

interface DashboardStats {
  totalContracts: number;
  activeContracts: number;
  monthlyCosts: number;
  potentialSavings: number;
  upcomingCancellations: number;
}

export default function DashboardSection() {
  const { data: contracts } = useQuery<Contract[]>({
    queryKey: ["/api/contracts"],
  });

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'optimized':
        return 'bg-green-100 text-green-800';
      case 'needs_review':
        return 'bg-red-100 text-red-800';
      case 'active':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'optimized':
        return 'Optimiert';
      case 'needs_review':
        return 'Prüfung erforderlich';
      case 'active':
        return 'Aktiv';
      default:
        return status;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'energy':
        return '⚡';
      case 'telecom':
        return '📱';
      case 'insurance':
        return '🛡️';
      default:
        return '📄';
    }
  };

  return (
    <section className="py-20 bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Ihr persönliches Vertrags-Dashboard</h2>
          <p className="text-xl text-gray-300">Behalten Sie alle Ihre Verträge im Überblick</p>
        </div>
        
        {/* Dashboard Mock */}
        <Card className="bg-gray-800 shadow-2xl">
          <CardContent className="p-8">
            {/* Dashboard Header */}
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8 space-y-4 lg:space-y-0">
              <div>
                <h3 className="text-2xl font-bold mb-2 text-white">Dashboard Übersicht</h3>
                <p className="text-gray-400">Ihre Vertragsoptimierung auf einen Blick</p>
              </div>
              <div className="flex space-x-4">
                <Button 
                  onClick={() => window.location.href = '/dashboard'}
                  className="btn-genius-primary"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Zum Dashboard
                </Button>
              </div>
            </div>
            
            {/* Stats Cards */}
            {stats && (
              <div className="grid md:grid-cols-4 gap-6 mb-8">
                <Card className="bg-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Aktive Verträge</p>
                        <p className="text-2xl font-bold text-white">{stats.activeContracts}</p>
                      </div>
                      <FileText className="h-8 w-8 text-[var(--genius-primary)]" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Monatliche Kosten</p>
                        <p className="text-2xl font-bold text-white">€{stats.monthlyCosts.toFixed(2)}</p>
                      </div>
                      <Euro className="h-8 w-8 text-red-500" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Einsparpotential</p>
                        <p className="text-2xl font-bold text-green-400">€{stats.potentialSavings.toFixed(2)}</p>
                      </div>
                      <TrendingUp className="h-8 w-8 text-green-500" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Kündigungen fällig</p>
                        <p className="text-2xl font-bold text-orange-400">{stats.upcomingCancellations}</p>
                      </div>
                      <AlertTriangle className="h-8 w-8 text-orange-500" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
            
            {/* Contracts Table */}
            <Card className="bg-gray-700 overflow-hidden">
              <div className="p-6 border-b border-gray-600">
                <h4 className="text-xl font-semibold text-white">Ihre Verträge</h4>
              </div>
              
              <div className="overflow-x-auto">
                {contracts && contracts.length > 0 ? (
                  <table className="w-full">
                    <thead className="bg-gray-600">
                      <tr>
                        <th className="text-left p-4 text-sm font-medium text-gray-300">Anbieter</th>
                        <th className="text-left p-4 text-sm font-medium text-gray-300">Kategorie</th>
                        <th className="text-left p-4 text-sm font-medium text-gray-300">Kosten/Monat</th>
                        <th className="text-left p-4 text-sm font-medium text-gray-300">Status</th>
                        <th className="text-left p-4 text-sm font-medium text-gray-300">Aktionen</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-600">
                      {contracts.slice(0, 3).map((contract) => (
                        <tr key={contract.id} className="hover:bg-gray-600 transition-colors">
                          <td className="p-4">
                            <div className="flex items-center space-x-3">
                              <div className="w-8 h-8 bg-[var(--genius-primary)] rounded-full flex items-center justify-center text-white text-sm">
                                {getCategoryIcon(contract.category)}
                              </div>
                              <span className="text-white">{contract.provider}</span>
                            </div>
                          </td>
                          <td className="p-4 text-gray-300 capitalize">{contract.subcategory || contract.category}</td>
                          <td className="p-4 font-semibold text-white">€{parseFloat(contract.monthlyCost).toFixed(2)}</td>
                          <td className="p-4">
                            <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(contract.status || 'unknown')}`}>
                              {getStatusText(contract.status || 'unknown')}
                            </span>
                          </td>
                          <td className="p-4">
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-[var(--genius-primary)] hover:text-[var(--genius-primary)]/80"
                              >
                                <Search className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-[var(--genius-secondary)] hover:text-[var(--genius-secondary)]/80"
                              >
                                <Sparkles className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="p-8 text-center">
                    <FileText className="h-16 w-16 text-gray-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-300 mb-2">Keine Verträge vorhanden</h3>
                    <p className="text-gray-400 mb-4">Laden Sie Ihren ersten Vertrag hoch, um zu beginnen.</p>
                    <Button 
                      onClick={() => window.location.href = '/dashboard'}
                      className="btn-genius-primary"
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Ersten Vertrag hinzufügen
                    </Button>
                  </div>
                )}
              </div>
              
              {contracts && contracts.length > 3 && (
                <div className="p-4 bg-gray-600 text-center">
                  <Button 
                    onClick={() => window.location.href = '/dashboard'}
                    variant="ghost"
                    className="text-[var(--genius-primary)] hover:text-[var(--genius-primary)]/80"
                  >
                    Alle {contracts.length} Verträge anzeigen →
                  </Button>
                </div>
              )}
            </Card>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
