import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Trash2, 
  Search, 
  Sparkles, 
  Calendar,
  Euro,
  AlertTriangle,
  CheckCircle,
  Eye
} from "lucide-react";
import type { Contract } from "@shared/schema";

interface ContractCardProps {
  contract: Contract;
  onDelete: () => void;
  onReanalyze: () => void;
  isDeleting?: boolean;
  isReanalyzing?: boolean;
}

export default function ContractCard({ 
  contract, 
  onDelete, 
  onReanalyze, 
  isDeleting = false, 
  isReanalyzing = false 
}: ContractCardProps) {
  const [showDetails, setShowDetails] = useState(false);

  const getStatusColor = (status: string | null) => {
    switch (status) {
      case 'optimized':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'needs_review':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'active':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: string | null) => {
    switch (status) {
      case 'optimized':
        return 'Optimiert';
      case 'needs_review':
        return 'Prüfung erforderlich';
      case 'active':
        return 'Aktiv';
      default:
        return status || 'Unbekannt';
    }
  };

  const getStatusIcon = (status: string | null) => {
    switch (status) {
      case 'optimized':
        return <CheckCircle className="h-4 w-4" />;
      case 'needs_review':
        return <AlertTriangle className="h-4 w-4" />;
      default:
        return null;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'energy':
        return '⚡';
      case 'telecom':
        return '📱';
      case 'insurance':
        return '🛡️';
      default:
        return '📄';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'energy':
        return 'text-yellow-600';
      case 'telecom':
        return 'text-blue-600';
      case 'insurance':
        return 'text-green-600';
      default:
        return 'text-gray-600';
    }
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return '-';
    const d = new Date(date);
    return d.toLocaleDateString('de-DE');
  };

  const getSavingsPotential = () => {
    if (contract.optimizationSuggestions) {
      const opts = contract.optimizationSuggestions as any;
      if (opts.potentialSavings) {
        return Math.round(opts.potentialSavings / 12); // Monthly savings
      }
    }
    return null;
  };

  const savingsPotential = getSavingsPotential();

  return (
    <Card className="card-genius">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg ${getCategoryColor(contract.category)} bg-gray-50`}>
              {getCategoryIcon(contract.category)}
            </div>
            <div>
              <CardTitle className="text-lg">{contract.provider}</CardTitle>
              <p className="text-sm text-gray-600 capitalize">
                {contract.subcategory || contract.category}
              </p>
            </div>
          </div>
          <Badge className={`${getStatusColor(contract.status)} flex items-center gap-1`}>
            {getStatusIcon(contract.status)}
            {getStatusText(contract.status)}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Main Info */}
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center space-x-2">
            <Euro className="h-4 w-4 text-gray-500" />
            <div>
              <p className="text-sm text-gray-600">Monatlich</p>
              <p className="font-semibold">€{parseFloat(contract.monthlyCost).toFixed(2)}</p>
            </div>
          </div>
          
          {contract.cancellationDate && (
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-gray-500" />
              <div>
                <p className="text-sm text-gray-600">Kündbar bis</p>
                <p className="font-semibold">{formatDate(contract.cancellationDate)}</p>
              </div>
            </div>
          )}
        </div>

        {/* Savings Potential */}
        {savingsPotential && savingsPotential > 0 && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-green-800">
                Monatliches Einsparpotential
              </span>
              <span className="font-bold text-green-800">€{savingsPotential}</span>
            </div>
          </div>
        )}

        {/* Contract Details Toggle */}
        {showDetails && (
          <div className="bg-gray-50 rounded-lg p-3 space-y-2">
            <div className="grid grid-cols-2 gap-2 text-sm">
              {contract.contractNumber && (
                <div>
                  <span className="text-gray-600">Vertragsnummer:</span>
                  <p className="font-medium">{contract.contractNumber}</p>
                </div>
              )}
              {contract.startDate && (
                <div>
                  <span className="text-gray-600">Startdatum:</span>
                  <p className="font-medium">{formatDate(contract.startDate)}</p>
                </div>
              )}
              {contract.endDate && (
                <div>
                  <span className="text-gray-600">Enddatum:</span>
                  <p className="font-medium">{formatDate(contract.endDate)}</p>
                </div>
              )}
              {contract.fileName && (
                <div>
                  <span className="text-gray-600">Datei:</span>
                  <p className="font-medium text-xs">{contract.fileName}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowDetails(!showDetails)}
            className="flex-1"
          >
            <Eye className="h-4 w-4 mr-1" />
            {showDetails ? 'Weniger' : 'Details'}
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={onReanalyze}
            disabled={isReanalyzing}
            className="text-[var(--genius-secondary)] hover:text-[var(--genius-secondary)]/80 border-[var(--genius-secondary)]/20 hover:border-[var(--genius-secondary)]/40"
          >
            {isReanalyzing ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-[var(--genius-secondary)] mr-1"></div>
            ) : (
              <Sparkles className="h-4 w-4 mr-1" />
            )}
            {isReanalyzing ? 'Analyse...' : 'Neu analysieren'}
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={onDelete}
            disabled={isDeleting}
            className="text-red-600 hover:text-red-700 border-red-200 hover:border-red-300"
          >
            {isDeleting ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-600"></div>
            ) : (
              <Trash2 className="h-4 w-4" />
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
