import nodemailer from 'nodemailer';
import { storage } from '../storage';
import type { EmailNotification } from '@shared/schema';

export class EmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: false,
      auth: {
        user: process.env.SMTP_USER || process.env.EMAIL_USER || 'default_user',
        pass: process.env.SMTP_PASS || process.env.EMAIL_PASS || 'default_pass',
      },
    });
  }

  async sendCancellationReminder(userEmail: string, contractProvider: string, cancellationDate: string) {
    const mailOptions = {
      from: process.env.FROM_EMAIL || 'noreply@genius-ai.com',
      to: userEmail,
      subject: `Kündigungserinnerung: ${contractProvider}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #007BFF;">Kündigungserinnerung</h2>
          <p>Sehr geehrte Damen und Herren,</p>
          <p>Ihr Vertrag mit <strong>${contractProvider}</strong> kann bis zum <strong>${cancellationDate}</strong> gekündigt werden.</p>
          <p>Möchten Sie Ihren Vertrag optimieren? Loggen Sie sich in Ihr GENIUS.AI Dashboard ein.</p>
          <a href="${process.env.APP_URL || 'https://your-domain.com'}/dashboard" 
             style="background: #007BFF; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block; margin: 20px 0;">
            Zum Dashboard
          </a>
          <p>Mit freundlichen Grüßen,<br>Ihr GENIUS.AI Team</p>
        </div>
      `,
    };

    try {
      await this.transporter.sendMail(mailOptions);
      return true;
    } catch (error) {
      console.error('Failed to send cancellation reminder:', error);
      return false;
    }
  }

  async sendOptimizationNotification(userEmail: string, savings: number, contractProvider: string) {
    const mailOptions = {
      from: process.env.FROM_EMAIL || 'noreply@genius-ai.com',
      to: userEmail,
      subject: `Neue Optimierungsmöglichkeit gefunden - Sparen Sie €${savings}/Jahr`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #007BFF;">Neue Optimierungsmöglichkeit!</h2>
          <p>Sehr geehrte Damen und Herren,</p>
          <p>Wir haben eine neue Optimierungsmöglichkeit für Ihren Vertrag mit <strong>${contractProvider}</strong> gefunden.</p>
          <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #28A745; margin: 0;">Jährliche Ersparnis: €${savings}</h3>
          </div>
          <p>Loggen Sie sich in Ihr Dashboard ein, um die Details zu sehen und den Wechsel zu starten.</p>
          <a href="${process.env.APP_URL || 'https://your-domain.com'}/dashboard" 
             style="background: #28A745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block; margin: 20px 0;">
            Optimierung ansehen
          </a>
          <p>Mit freundlichen Grüßen,<br>Ihr GENIUS.AI Team</p>
        </div>
      `,
    };

    try {
      await this.transporter.sendMail(mailOptions);
      return true;
    } catch (error) {
      console.error('Failed to send optimization notification:', error);
      return false;
    }
  }

  async sendNewsletterConfirmation(email: string) {
    const mailOptions = {
      from: process.env.FROM_EMAIL || 'noreply@genius-ai.com',
      to: email,
      subject: 'Willkommen beim GENIUS.AI Newsletter',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #007BFF;">Willkommen beim GENIUS.AI Newsletter!</h2>
          <p>Vielen Dank für Ihr Interesse an unserem Newsletter.</p>
          <p>Sie erhalten ab sofort wöchentliche Updates zu:</p>
          <ul>
            <li>Neuen Tarifen und Anbietern</li>
            <li>Optimierungstipps</li>
            <li>Marktanalysen</li>
            <li>Exklusiven Angeboten</li>
          </ul>
          <p>Mit freundlichen Grüßen,<br>Ihr GENIUS.AI Team</p>
          <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
          <p style="font-size: 12px; color: #666;">
            Sie können sich jederzeit vom Newsletter abmelden, indem Sie auf den Link in unseren E-Mails klicken.
          </p>
        </div>
      `,
    };

    try {
      await this.transporter.sendMail(mailOptions);
      return true;
    } catch (error) {
      console.error('Failed to send newsletter confirmation:', error);
      return false;
    }
  }

  async processPendingNotifications() {
    try {
      const notifications = await storage.getPendingNotifications();
      
      for (const notification of notifications) {
        let success = false;
        
        // Get user email
        const user = await storage.getUser(notification.userId);
        if (!user?.email) continue;

        switch (notification.type) {
          case 'cancellation_reminder':
            if (notification.contractId) {
              const contract = await storage.getContract(notification.contractId, notification.userId);
              if (contract) {
                success = await this.sendCancellationReminder(
                  user.email,
                  contract.provider,
                  contract.cancellationDate?.toString() || 'N/A'
                );
              }
            }
            break;
          
          case 'optimization_available':
            // This would need more context about the optimization
            success = await this.sendOptimizationNotification(user.email, 150, 'Ihr Anbieter');
            break;
        }

        if (success) {
          await storage.markNotificationSent(notification.id);
        }
      }
    } catch (error) {
      console.error('Failed to process pending notifications:', error);
    }
  }
}

export const emailService = new EmailService();
