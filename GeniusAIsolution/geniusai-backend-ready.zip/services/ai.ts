import OpenAI from "openai";
import { trackingService } from './tracking';

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface ContractAnalysis {
  provider: string;
  category: string;
  subcategory: string;
  contractNumber?: string;
  monthlyCost: number;
  startDate?: string;
  endDate?: string;
  cancellationDate?: string;
  keyTerms: string[];
  risks: string[];
  optimizationPotential: number; // 0-100
}

export interface OptimizationSuggestions {
  currentCost: number;
  suggestedCost: number;
  potentialSavings: number;
  recommendations: Array<{
    provider: string;
    plan: string;
    monthlyCost: number;
    benefits: string[];
    switchingSteps: string[];
    comparisonUrl?: string; // Check24 affiliate tracking URL
  }>;
  marketComparison: {
    averageMarketPrice: number;
    yourPosition: 'below_average' | 'average' | 'above_average';
    percentile: number;
  };
}

export class AIService {
  async analyzeContract(ocrText: string): Promise<ContractAnalysis> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Du bist ein Experte für deutsche Vertragsanalyse. Analysiere den folgenden Vertragstext und extrahiere wichtige Informationen. 
            Antworte im JSON-Format mit diesen Feldern:
            - provider: Anbieter/Unternehmen
            - category: Kategorie (energy, telecom, insurance)
            - subcategory: Unterkategorie (strom, gas, internet, mobile, kfz, etc.)
            - contractNumber: Vertragsnummer falls vorhanden
            - monthlyCost: Monatliche Kosten in Euro (nur Zahl)
            - startDate: Startdatum (YYYY-MM-DD)
            - endDate: Enddatum (YYYY-MM-DD)
            - cancellationDate: Kündigungsdatum (YYYY-MM-DD)
            - keyTerms: Array wichtiger Vertragskonditionen
            - risks: Array identifizierter Risiken
            - optimizationPotential: Optimierungspotential 0-100`
          },
          {
            role: "user",
            content: ocrText
          }
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      return result as ContractAnalysis;
    } catch (error) {
      console.error('AI contract analysis failed:', error);
      throw new Error('Failed to analyze contract with AI');
    }
  }

  async generateOptimizationSuggestions(
    analysis: ContractAnalysis, 
    category: string,
    postcode?: string
  ): Promise<OptimizationSuggestions> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Du bist ein Experte für deutsche Tarifoptimierung. Generiere Optimierungsvorschläge basierend auf der Vertragsanalyse.
            Berücksichtige aktuelle deutsche Marktpreise für ${category}.
            Antworte im JSON-Format mit:
            - currentCost: Aktuelle monatliche Kosten
            - suggestedCost: Vorgeschlagene monatliche Kosten
            - potentialSavings: Jährliche Einsparungen
            - recommendations: Array mit Empfehlungen (provider, plan, monthlyCost, benefits, switchingSteps)
            - marketComparison: Marktvergleich (averageMarketPrice, yourPosition, percentile)`
          },
          {
            role: "user",
            content: JSON.stringify(analysis)
          }
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || '{}') as OptimizationSuggestions;
      
      // Add Check24 tracking URLs to recommendations
      if (result.recommendations) {
        result.recommendations = result.recommendations.map(rec => ({
          ...rec,
          comparisonUrl: trackingService.generateOptimizationTrackingUrl(
            analysis.category,
            analysis.subcategory || 'unknown',
            rec.provider,
            postcode
          )
        }));
      }
      
      return result;
    } catch (error) {
      console.error('AI optimization generation failed:', error);
      throw new Error('Failed to generate optimization suggestions');
    }
  }

  async generateChatResponse(message: string, userId: string): Promise<string> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Du bist GENIUS Assistant, ein hilfreicher KI-Assistent für Vertragsoptimierung in Deutschland.
            Antworte höflich und professionell auf Deutsch. Helfe bei Fragen zu Verträgen, Tarifen und Optimierungen.
            Halte Antworten präzise und hilfreich.`
          },
          {
            role: "user",
            content: message
          }
        ],
        max_tokens: 500,
      });

      return response.choices[0].message.content || 'Entschuldigung, ich konnte Ihre Anfrage nicht verarbeiten.';
    } catch (error) {
      console.error('AI chat response failed:', error);
      return 'Entschuldigung, es gab ein Problem bei der Verarbeitung Ihrer Anfrage.';
    }
  }
}

export const aiService = new AIService();
